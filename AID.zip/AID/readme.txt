
set environment variables

export JAVA_HOME=/slot/ems1143/oracle/beahome/jdk160_11
export AIA_HOME=/slot/ems1143/oracle/FP30
export ANT_HOME=$AIA_HOME/apache-ant-1.7.0
export PATH=:$JAVA_HOME/bin:$ANT_HOME/bin:$PATH
export WL_HOME=/slot/ems1143/oracle/beahome/wlserver_10.3
export CLASSPATH=/slot/ems1143/oracle/beahome/wlserver_10.3/server/lib/weblogic.jar


( modify according to platform specifications and add aditional variables if required in the scripts to be run )



to run file --

navigate to the AID directory and then

ant -f AIAInstallDriver.xml -DDeploymentPlan.file=AIADeploymentPlan.xml
