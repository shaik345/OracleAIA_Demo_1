import sys
from java.lang import System

global props

adminhost = sys.argv[1]
adminport = sys.argv[2]
usr = sys.argv[3]
password = sys.argv[4]
targetserver = sys.argv[5]
managedserver = sys.argv[6]
managedserverport = sys.argv[7]

adminurl='t3://'+adminhost+':'+adminport
soaurl='t3://'+managedserver+':'+managedserverport

try:
    connect(userConfigFile=usr,userKeyFile=password,url=adminurl)
except:
 raise Exception('Error connecting to server please check to see if the server exists')

else:
    try:


       dir=cmo.getRootDirectory()
       cd ('Clusters/'+targetserver+'/Servers')
       ServerList=ls(returnMap="true")
       for i in range(0, len(ServerList)):
             print ServerList[i]
             errorlog=dir+"/servers/"+ServerList[i]+"/logs/aia-error.log"
             tracelog=dir+"/servers/"+ServerList[i]+"/logs/aia-trace.log"
             debuglog=dir+"/servers/"+ServerList[i]+"/logs/aia-debug.log"
             setLogLevel(target=ServerList[i], logger="oracle.aia.logging.error",addLogger=1,level="NOTIFICATION:1")
             setLogLevel(target=ServerList[i], logger="oracle.aia.logging.trace",addLogger=1,level="NOTIFICATION:1")
             setLogLevel(target=ServerList[i], logger="oracle.aia.logging.debug",addLogger=1,level="NOTIFICATION:1")
             first = listLogHandlers(target=ServerList[i], name='aia-log-error-handler')
             if not first:
                   configureLogHandler(target=ServerList[i], name="aia-log-error-handler",handlerType="oracle.core.ojdl.logging.ODLHandlerFactory",level="TRACE:32",maxFileSize="10485760",maxLogSize="104857600",addToLogger="oracle.aia.logging.error",addHandler=true,path=errorlog,useParentHandlers=false,format="ODL-XML")
             second = listLogHandlers(target=ServerList[i], name='aia-log-trace-handler')
             if not second:
                   configureLogHandler(target=ServerList[i], name="aia-log-trace-handler",handlerType="oracle.core.ojdl.logging.ODLHandlerFactory",level="TRACE:32",maxFileSize="10485760",maxLogSize="104857600",addToLogger="oracle.aia.logging.trace",addHandler=true,path=tracelog,useParentHandlers=false,format="ODL-XML")
             third = listLogHandlers(target=ServerList[i], name='aia-log-debug-handler')
             if not third:
                   configureLogHandler(target=ServerList[i], name="aia-log-debug-handler",handlerType="oracle.core.ojdl.logging.ODLHandlerFactory",level="TRACE:32",maxFileSize="10485760",maxLogSize="104857600",addToLogger="oracle.aia.logging.debug",addHandler=true,path=debuglog,useParentHandlers=false,encoding="UTF-8")

    except:
     dumpStack()
     raise
dumpStack()
disconnect()


exit()


