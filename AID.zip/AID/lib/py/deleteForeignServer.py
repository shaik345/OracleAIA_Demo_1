import sys
from java.lang import System

import wlstModule as wl

print '@@@ Starting the script ...'
global props


adminhost = sys.argv[1]
adminport = sys.argv[2]
usr = sys.argv[3]
password = sys.argv[4]
targetServer= sys.argv[5]
serverType=sys.argv[6]
jmsForeignServerName = sys.argv[7]
jmsModuleName = sys.argv[8]

url='t3://'+adminhost+':'+adminport


try:
 connect(usr,password,url)
except:
 raise Exception('Error connecting to server please check to see if the server exists')

else:
    edit()
    cancelEdit('y')

    edit()
    startEdit()
    cd('/')

    servermb=getMBean( serverType+'s/'+targetServer)
    if servermb is None:
        print '@@@ No server MBean found'
    else:

        # Create JMS Foreign Server

      try:
          jmsModuleMBean = getMBean('JMSSystemResources'+'/'+jmsModuleName)
          jmsModule=jmsModuleMBean.getJMSResource()
          print 'Attempting to delete Foreign Server :' + jmsForeignServerName
          jmsForeignServerObject = jmsModule.lookupForeignServer(jmsForeignServerName)
          if jmsForeignServerObject is None:
              print 'WARNING!!! Foreign Server does not exist'
          else:
              jmsForeignServer = jmsModule.destroyForeignServer(jmsForeignServerObject)
              print 'Deleted Foreign Server successfully'
      except:
             raise
        
validate()
save()
activate(block="true")
dumpStack()
disconnect()
