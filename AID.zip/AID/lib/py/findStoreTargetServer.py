import sys
from java.lang import System
import wlstModule as wl

def lsDataStoreTargetServers(storeType, storeName):
	# Find number of data stores exists on Server		
	farIndex = 0
	if storeType == 'FileStore':
		path = '/FileStores/'		
	elif storeType == 'JDBCStore':
		path = '/JDBCStores/'
		
	prefix = storeName+'_'			
	dSTargetServerList = [0]	
	wl.cd(path)
	dsl = wl.ls(returnMap='true') 	
		
	for dslToken in dsl:				
		# Iterate over the Data Stores start with Predefined Prefix
		#dslToken = dslToken.strip().lstrip().rstrip()
		if len(dslToken) > 0  and dslToken.find(prefix) >= 0:				
			# find farIndex			
			index = dslToken[dslToken.rfind('_')+1:len(dslToken)]			
			
			# Compute Max Index in available Data Stores
			try:				
				if farIndex < int(index):
					farIndex = int(index)
			except:
				raise Exception('ERROR!!! Invalid Index : '+index+' Ignored')
							
			wl.cd(path+dslToken+'/Targets')
			targetS = wl.ls(returnMap='true')
			for targetToken in targetS:					
				if len(targetToken) > 0:
					print 'Target Server Associated :'+targetToken
					dSTargetServerList.append(targetToken)		
	dSTargetServerList[0] = (farIndex + 1)
	return dSTargetServerList

def lsTargetServerJMSServers(targetServer, jmsServerPrefix):
	jmsServerList = []
	wl.cd('/JMSServers/')
	jmsServers = wl.ls(returnMap='true')
	for jmsServer in jmsServers:
		if jmsServer.rfind(jmsServerPrefix) >= 0:
			wl.cd('/JMSServers/'+jmsServer+'/Targets')
			targetServers = wl.ls(returnMap='true')
			if targetServer in targetServers:
				jmsServerList.append(jmsServer)
	return jmsServerList
	
	
def	lsJMSServerDataStores(jmsServerName):
	print '/JMSServers/'+jmsServerName+'/PersistentStore/'
	wl.cd('/JMSServers/'+jmsServerName+'/PersistentStore/')
	dataStores = wl.ls(returnMap='true')
	return dataStores
	