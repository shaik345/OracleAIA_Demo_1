import sys
from java.lang import System
import os
import wlstModule as wl

global props

host = sys.argv[1]
port=sys.argv[2]
usr = sys.argv[3]
password = sys.argv[4]
servertype = sys.argv[5]
soaserver = sys.argv[6]
directory = sys.argv[7]

adminurl='t3://'+host+':'+port




try:
 connect(userConfigFile=usr,userKeyFile=password,url=adminurl)
except:
 raise Exception('Error connecting to server please check to see if the server exists')

else:
    cd('/')
    mserver=soaserver
    if servertype == 'Cluster':
        domainConfig()
        cd ('/Clusters/'+soaserver)
        managedServers=cmo.getServers()
        print managedServers
## Loop through managed servers
        domainRuntime()
        for managedServer in managedServers:
                try:
                        managedServerName=managedServer.getName()
                        print 'Trying ' + managedServerName
                        cd('/ServerRuntimes/'+managedServerName)
                        if cmo.getState() == 'RUNNING':
                                mserver=managedServerName
			break;
                except:
                        print 'skipping ' + managedServerName

    try:
         print mserver
         deleteMetadata('soa-infra', mserver, directory)
    except:
         dumpStack()
         raise Exception('Error!!! Delete MetaData Failed !!')
    else:
         print 'Delete Metadata Successful !!'

disconnect()

