import sys
from java.lang import System

import wlstModule as wl

print '@@@ Starting the script ...'
global props


adminhost = sys.argv[1]
adminport = sys.argv[2]
usr = sys.argv[3]
password = sys.argv[4]
targetServer= sys.argv[5]
serverType=sys.argv[6]+'s'
jmsModuleName = sys.argv[7]

url='t3://'+adminhost+':'+adminport


try:
 connect(usr,password,url)
except:
 raise Exception('Error connecting to server please check to see if the server exists')

else:
    edit()
    cancelEdit('y')

    edit()
    startEdit()
    cd('/')

    servermb=getMBean( serverType+'/'+targetServer)
    if servermb is None:
     print '@@@ No server MBean found'
    else:

        # Create JMS Module
          
      try:
         try:
             print 'attempting to create JMS Module :' + jmsModuleName
             jmsModuleMBean = create(jmsModuleName,"JMSSystemResource")
         except:
             print 'Error Creating JMS Module..'
         else:

             jmsModuleMBean.addTarget(servermb)

      except:
          raise

validate()
save()
activate(block="true")
dumpStack()
disconnect()
