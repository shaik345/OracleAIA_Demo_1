import sys
from java.lang import System

global props

adminhost = sys.argv[1]
adminport = sys.argv[2]
wlusr = sys.argv[3]
wlpswd = sys.argv[4]
newuser = sys.argv[5]

url='t3://'+adminhost+':'+adminport

try:
 connect(wlusr,wlpswd,url)
except:
 raise Exception('Error connecting to server please check to see if the server exists')
else:
  try:
     atnr=cmo.getSecurityConfiguration().getDefaultRealm().lookupAuthenticationProvider("DefaultAuthenticator")
     try:
       atnr.removeUser(newuser)
       print newuser,'User deleted.'
     except:
       print newuser,'User not found.'
  except:
    dumpStack()
    raise 
dumpStack()
disconnect()
