import sys
import string
from java.lang import System

print '@@@ Starting the deployment script ...'
global props

adminhost = sys.argv[1]
adminport = sys.argv[2]
usr = sys.argv[3]
password = sys.argv[4]
applicationName = sys.argv[5]
filepath = sys.argv[6]
targetserver = sys.argv[7]
deploymentOrder = sys.argv[8]
isLibraryModule = sys.argv[9]
planPath = sys.argv[10]

url='t3://'+adminhost+':'+adminport
connect(usr,password,url)

edit()
cancelEdit('y')

edit()
startEdit()
cd('/')
if planPath == 'null':
    print '-----------Without planPath ---------'
    progress= deploy(appName=applicationName,path=filepath,targets=targetserver,upload='true',stage='true', libraryModule=isLibraryModule)
    progress.printStatus()
else:
    print '------With planPath---------'
    progress= deploy(appName=applicationName,path=filepath,targets=targetserver,upload='true',stage='true', libraryModule=isLibraryModule, planPath=planPath)
    progress.printStatus()

save()

cd('/')
apps=cmo.getAppDeployments()

for app in apps:
    if app.getName().startswith(applicationName):
        appBean = getMBean('/AppDeployments/'+app.getName())
        appBean.setDeploymentOrder(500)

save()
dumpStack()
activate()
disconnect()

