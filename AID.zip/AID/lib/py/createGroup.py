import sys
from java.lang import System

global props

adminhost = sys.argv[1]
adminport = sys.argv[2]
usr = sys.argv[3]
password = sys.argv[4]
name = sys.argv[5]
displayname = sys.argv[6:]
namelen = len(displayname)
displaystr = ""
displaylist = []
namelist = []
i = 0

while i < namelen:
 displaystr = displaystr + displayname[i] + " "
 i = i + 1
while ',' in displaystr:
 index = displaystr.index(',')
 displaylist.append(displaystr[:index])
 displaystr = displaystr[index + 1:]
displaylist.append(displaystr)

while ',' in name:
 index = name.index(',')
 namelist.append(name[:index])
 name = name[index + 1:]
namelist.append(name)

url='t3://'+adminhost+':'+adminport

try:
 connect(usr,password,url)
except:
 raise Exception('Error connecting to server please check to see if the server exists')
else:
  try:
    j = 0
    while j < len(namelist):
     atnr=cmo.getSecurityConfiguration().getDefaultRealm().lookupAuthenticationProvider("DefaultAuthenticator")
     try:
       atnr.createGroup(namelist[j],displaylist[j])
       print namelist[j],' Group created.'
     except:
	print namelist[j],' Group already exists.'
     j = j + 1
  except:
    dumpStack()
    raise 
dumpStack()
disconnect()
