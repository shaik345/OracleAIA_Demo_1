import sys
from java.lang import System

import wlstModule as wl

print '@@@ Starting the script ...'
global props


adminhost = sys.argv[1]
adminport = sys.argv[2]
usr = sys.argv[3]
password = sys.argv[4]
targetServer= sys.argv[5]
serverType=sys.argv[6]+'s'
jmsServerName = sys.argv[7]
storeType = sys.argv[8]
storeName = sys.argv[9]
jmsModuleName = sys.argv[10]
dbStoreDataSourceName = sys.argv[11]
jmsSubDeploymentName = sys.argv[12]

url='t3://'+adminhost+':'+adminport


try:
 connect(usr,password,url)
except:
 raise Exception('Error connecting to server please check to see if the server exists')

else:
    edit()
    cancelEdit('y')

    edit()
    startEdit()
    cd('/')

    servermb=getMBean( serverType+'/'+targetServer)
    if servermb is None:
     print '@@@ No server MBean found'
    else:

        # Create JMS Server
          
      try:
         try:
             print 'attempting to create JMS Server :' + jmsServerName
             jmsServerMbean = create(jmsServerName,'JMSServer')
         except:
             print 'Error Creating JMS Server..'
         else:

             jmsServerMbean.addTarget(servermb)
             jmsModuleMBean = create(jmsModuleName,"JMSSystemResource")
             jmsModuleMBean.addTarget(servermb)
             subDepMbean = jmsModuleMBean.createSubDeployment(jmsSubDeploymentName)
             subDepMbean.addTarget(jmsServerMbean)

             if storeType == 'JDBCStore':
               print 'attempting to create JDBC store with name :' + storeName
               dbStore = create(storeName,"JDBCStore")
               dbStore.addTarget(servermb)
               dbStoreDS = getMBean('SystemResources/'+dbStoreDataSourceName)
               print 'Datasource name : '+dbStoreDS.getJDBCResource().getName()
               dbStore.setDataSource(dbStoreDS)
               dbStore.setPrefixName(storeName)
               jmsServerMbean.setPersistentStore(dbStore)

             if storeType == 'FileStore':
               fileStore = create(storeName, "FileStore")
               fileStore.addTarget(servermb)
               fileStore.setDirectory(storeName)
               jmsServerMbean.setPersistentStore(fileStore)

      except:
          raise

validate()
save()
activate(block="true")
dumpStack()
disconnect()

