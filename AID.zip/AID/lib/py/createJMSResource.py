import sys
from java.lang import System

import wlstModule as wl

print '@@@ Starting the script ...'
global props


adminhost = sys.argv[1]
adminport = sys.argv[2]
usr = sys.argv[3]
password = sys.argv[4]
targetServer= sys.argv[5]
serverType=sys.argv[6]
jmsResourceType = sys.argv[7]
jmsResourceName = sys.argv[8]
jmsResourceJNDI = sys.argv[9]
jmsModuleName = sys.argv[10]
jmsSubDeploymentName = sys.argv[11]

url='t3://'+adminhost+':'+adminport


try:
 connect(usr,password,url)
except:
 raise Exception('Error connecting to server please check to see if the server exists')

else:
    edit()
    cancelEdit('y')

    edit()
    startEdit()
    cd('/')

    servermb=getMBean( serverType+'s/'+targetServer)
    if servermb is None:
        print '@@@ No server MBean found'
    else:
        jmsModuleMbean = getMBean('JMSSystemResources'+'/'+jmsModuleName)
        jmsModule = jmsModuleMbean.getJMSResource()

        if jmsResourceType == 'ConnectionFactory':
            print 'Attempting to create connectionFactory with name '+ jmsResourceName
            jmsResourceBean = jmsModule.lookupConnectionFactory(jmsResourceName)
            if jmsResourceBean is None:
               jmsResourceBean = jmsModule.createConnectionFactory(jmsResourceName)
               jmsResourceBean.setJNDIName(jmsResourceJNDI)
               jmsResourceBean.setDefaultTargetingEnabled(true)
               print 'Created ConnectionFactory'
            else:
               print 'WARNING!!! Connection Factory already exists'

        elif jmsResourceType == 'Queue':
            if serverType == 'Cluster':
                print 'Attempting to create Queue with name '+ jmsResourceName
                jmsResourceBean = jmsModule.lookupUniformDistributedQueue(jmsResourceName)
                if jmsResourceBean is None:
                   jmsResourceBean = jmsModule.createUniformDistributedQueue(jmsResourceName)
                   jmsResourceBean.setJNDIName(jmsResourceJNDI)
                   jmsResourceBean.setSubDeploymentName(jmsSubDeploymentName)
                   print '***************** Queue created in Cluster ***************'
                else:
                   print 'WARNING!!! Queue already exists'
                print 'Attempting to create Error Queue with name '+ jmsResourceName+ '_ErrorQ'
                jmsErrorResourceBean = jmsModule.lookupUniformDistributedQueue(jmsResourceName+'_ErrorQ')
                if jmsErrorResourceBean is None:
                   jmsErrorResourceBean = jmsModule.createUniformDistributedQueue(jmsResourceName+'_ErrorQ')
                   jmsErrorResourceBean .setJNDIName(jmsResourceJNDI+'_ErrorQ')
                   jmsErrorResourceBean .setSubDeploymentName(jmsSubDeploymentName)
                   print '***************** Error Queue created in Cluster ***************'
                else:
                   print 'WARNING!!! Error Queue already exists'
                jmsDeliveryFailureBean=jmsResourceBean.getDeliveryFailureParams()
                jmsDeliveryFailureBean.setErrorDestination(jmsErrorResourceBean)
                jmsDeliveryFailureBean.setRedeliveryLimit(0)
                jmsDeliveryFailureBean.setExpirationPolicy('Redirect')
            else:
                print 'Attempting to create Queue with name '+ jmsResourceName
                jmsResourceBean = jmsModule.lookupQueue(jmsResourceName)
                if jmsResourceBean is None:
                   jmsResourceBean = jmsModule.createQueue(jmsResourceName)
                   jmsResourceBean.setJNDIName(jmsResourceJNDI)
                   jmsResourceBean.setSubDeploymentName(jmsSubDeploymentName)
                   print '***************** Queue created in Server ***************'
                else:
                   print 'WARNING!!! Queue already exists'
                print 'Attempting to create Error Queue with name '+ jmsResourceName+ '_ErrorQ'
                jmsErrorResourceBean = jmsModule.lookupQueue(jmsResourceName+'_ErrorQ')
                if jmsErrorResourceBean is None:
                   jmsErrorResourceBean = jmsModule.createQueue(jmsResourceName+'_ErrorQ')
                   jmsErrorResourceBean .setJNDIName(jmsResourceJNDI+'_ErrorQ')
                   jmsErrorResourceBean .setSubDeploymentName(jmsSubDeploymentName)
                   print '***************** Error Queue created in Server ***************'     
                else:
                   print 'WARNING!!! Error Queue already exists'
                jmsDeliveryFailureBean=jmsResourceBean.getDeliveryFailureParams()
                jmsDeliveryFailureBean.setErrorDestination(jmsErrorResourceBean)
                jmsDeliveryFailureBean.setRedeliveryLimit(0)
                jmsDeliveryFailureBean.setExpirationPolicy('Redirect')
                 
	    dumpStack()
	    print 'Created Queue and Error Queue'
        elif jmsResourceType == 'Topic':

            if serverType == 'Cluster':
                print 'Attempting to create Topic with name '+ jmsResourceName
                jmsResourceBean = jmsModule.lookupUniformDistributedTopic(jmsResourceName)
                if jmsResourceBean is None:
                   jmsResourceBean = jmsModule.createUniformDistributedTopic(jmsResourceName)
                   jmsResourceBean.setJNDIName(jmsResourceJNDI)
                   jmsResourceBean.setSubDeploymentName(jmsSubDeploymentName)
                   jmsResourceBean.setForwardingPolicy('Partitioned')
                   print '***************** Topic created in Cluster ***************'
                else:
                   print 'WARNING!!! Topic already exists'
                print 'Attempting to create Error Queue with name '+ jmsResourceName+ '_ErrorQ'
                jmsErrorResourceBean = jmsModule.lookupUniformDistributedQueue(jmsResourceName+'_ErrorQ')
                if jmsErrorResourceBean is None:
                   jmsErrorResourceBean = jmsModule.createUniformDistributedQueue(jmsResourceName+'_ErrorQ')
                   jmsErrorResourceBean .setJNDIName(jmsResourceJNDI+'_ErrorQ')
                   jmsErrorResourceBean .setSubDeploymentName(jmsSubDeploymentName)
                   print '***************** Error Queue created in Cluster ***************'
                else:
                   print 'WARNING!!! Error Queue already exists'
                jmsDeliveryFailureBean=jmsResourceBean.getDeliveryFailureParams()
                jmsDeliveryFailureBean.setErrorDestination(jmsErrorResourceBean)
                jmsDeliveryFailureBean.setRedeliveryLimit(0)
                jmsDeliveryFailureBean.setExpirationPolicy('Redirect')

            else:
                print 'Attempting to create Topic with name '+ jmsResourceName
                jmsResourceBean = jmsModule.lookupTopic(jmsResourceName)
                if jmsResourceBean is None:
                   jmsResourceBean = jmsModule.createTopic(jmsResourceName)
                   jmsResourceBean.setJNDIName(jmsResourceJNDI)
                   jmsResourceBean.setSubDeploymentName(jmsSubDeploymentName)
                   print '***************** Topic created in Server ***************'
                else:
                   print 'WARNING!!! Topic already exists'
                print 'Attempting to create Error Queue with name '+ jmsResourceName+ '_ErrorQ'
                jmsErrorResourceBean = jmsModule.lookupQueue(jmsResourceName+'_ErrorQ')
                if jmsErrorResourceBean is None:
                   jmsErrorResourceBean = jmsModule.createQueue(jmsResourceName+'_ErrorQ')
                   jmsErrorResourceBean .setJNDIName(jmsResourceJNDI+'_ErrorQ')
                   jmsErrorResourceBean .setSubDeploymentName(jmsSubDeploymentName)
                   print '***************** Error Queue created in Server ***************'       
                else:
                   print 'WARNING!!! Error Queue already exists'
                jmsDeliveryFailureBean=jmsResourceBean.getDeliveryFailureParams()
                jmsDeliveryFailureBean.setErrorDestination(jmsErrorResourceBean)
                jmsDeliveryFailureBean.setRedeliveryLimit(0)
                jmsDeliveryFailureBean.setExpirationPolicy('Redirect')
     
            print 'Created Topic and the Error Queue'

        else:
            raise Exception('Invalid JmsResourceType passed as an argument')


validate()
save()
activate(block="true")
dumpStack()
disconnect()

