import sys
from java.lang import System

import wlstModule as wl

global props

adminhost = sys.argv[1]
adminport = sys.argv[2]
adminuser = sys.argv[3]
adminpassword = sys.argv[4]
osmhost=sys.argv[5]
osmport=sys.argv[6]
osmuser=sys.argv[7]
osmpassword=sys.argv[8]
targetServer= sys.argv[9]
serverType=sys.argv[10]
jmssafRemoteContextName=sys.argv[11]
jmsModuleName=sys.argv[12]

url='t3://'+adminhost+':'+adminport
osmurl='t3://'+osmhost+':'+osmport

try:
 connect(adminuser,adminpassword,url)
except:
 raise Exception('Error connecting to server please check to see if the server is reachable')

else:
    edit()
    cancelEdit('y')

    edit()
    startEdit()
    cd('/')

    servermb=getMBean( serverType+'s/'+targetServer)
    if servermb is None:
        print '@@@ No server MBean found for '+targetServer
    else:
      jmsModuleMbean = getMBean('JMSSystemResources'+'/'+jmsModuleName)
      jmsModule = jmsModuleMbean.getJMSResource()
      jmssafRemoteContextBean = jmsModule.lookupSAFRemoteContext(jmssafRemoteContextName)
      if jmssafRemoteContextBean is None:
         jmssafRemoteContextBean = jmsModule.createSAFRemoteContext(jmssafRemoteContextName)
         jmssafRemoteContextBean.SAFLoginContext.setLoginURL(osmurl)
         jmssafRemoteContextBean.SAFLoginContext.setUsername(osmuser)
         jmssafRemoteContextBean.SAFLoginContext.setPassword(osmpassword)
         print 'Created SAF RemoteContext "'+jmssafRemoteContextName+'" successfully'
      else:
         print 'WARNING!!! SAF RemoteContext "'+jmssafRemoteContextName+'" already exists' 

activate()

startEdit()
validate()
save()
activate(block="true")
dumpStack()
disconnect()
