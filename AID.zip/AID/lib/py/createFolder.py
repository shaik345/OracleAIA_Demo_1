import sys
from java.lang import System

modulePath = os.environ["AIA_HOME"] + '/Infrastructure/Install/AID/lib/py'
if modulePath not in sys.path:
	print modulePath + ' imported!!!'
	sys.path.append(modulePath)
import findStoreTargetServer
global props

adminhost = sys.argv[1]
adminport = sys.argv[2]
usr = sys.argv[3]
password = sys.argv[4]
type=sys.argv[5]
targetserver = sys.argv[6]
rootdir = sys.argv[7]
storeName = 'AIADataStore'
notFound = False
adminurl='t3://'+adminhost+':'+adminport

try:
	connect(usr,password,adminurl)
except:
	raise Exception('Error connecting to server please check to see if the server exists')

else:
    try:
		if type == 'Cluster':
			dSTargetServers = findStoreTargetServer.lsDataStoreTargetServers('FileStore', storeName)			
			s = ls('/Clusters/' + targetserver + '/Servers')			
			for token in s.split("dr--"):
				token=token.strip().lstrip().rstrip()						
				if len(token) > 0 and not token == 'AdminServer' and token not in dSTargetServers:				
					print 'Creating Folder : AIADataStore_'+str(dSTargetServers[0])
					try:
					     os.makedirs(rootdir+'/AIADataStore_'+str(dSTargetServers[0]))
					     f = open(rootdir+'/AIADataStore_'+str(dSTargetServers[0])+'/temp', 'w')
					except:
						print 'DataStore Folder Found for AIADataStore_'+str(dSTargetServers[0])
					notFound = True
					dSTargetServers[0]=dSTargetServers[0]+1
						 
			if not notFound:				
				raise Exception('Error!!! No new node detected in Cluster!!')
		else:
			os.makedirs(rootdir+'/AIADataStore')
			f = open(rootdir+'/AIADataStore/temp', 'w')					
    except:
		dumpStack()
		raise
dumpStack()
disconnect()
exit()
