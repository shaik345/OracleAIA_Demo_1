import sys
from java.lang import System

import wlstModule as wl

global props

adminhost = sys.argv[1]
adminport = sys.argv[2]
adminuser = sys.argv[3]
adminpassword = sys.argv[4]
targetServer= sys.argv[5]
serverType=sys.argv[6]
jmssafResourceType=sys.argv[7]
jmssafResourceName=sys.argv[8]
jmsSAFImportedDestinations=sys.argv[9]
jmsModuleName=sys.argv[10]

url='t3://'+adminhost+':'+adminport

try:
 connect(adminuser,adminpassword,url)
except:
 raise Exception('Error connecting to server please check to see if the server is reachable')

else:
    edit()
    cancelEdit('y')

    edit()
    startEdit()
    cd('/')

    servermb=getMBean( serverType+'s/'+targetServer)
    if servermb is None:
        print '@@@ No server MBean found for '+targetServer
    else:
      jmsModuleMbean = getMBean('JMSSystemResources'+'/'+jmsModuleName)
      jmsModule = jmsModuleMbean.getJMSResource()

      jmssafImportedDestinationsBean = jmsModule.lookupSAFImportedDestinations(jmsSAFImportedDestinations)
      if jmssafImportedDestinationsBean is None:
         print 'No SAF ImportedDestinations Found with name '+ jmsSAFImportedDestinations
      else:
         if jmssafResourceType == 'Queue': 
            jmssafResourceBean = jmssafImportedDestinationsBean.lookupSAFQueue(jmssafResourceName)
            if jmssafResourceBean is None:
               print 'WARNING!!! SAF ImportedDestinations Queue "'+jmssafResourceName+'" doesnt exist'
            else:
               jmssafImportedDestinationsBean.destroySAFQueue(jmssafResourceBean)
               print 'Deleteded SAF ImportedDestinations Queue "'+jmssafResourceName+'" successfully'
         elif jmssafResourceType == 'Topic':
            print 'Deletion of SAF Topic is not supported yet'

activate()

startEdit()

validate()
save()
activate(block="true")
dumpStack()
disconnect()
