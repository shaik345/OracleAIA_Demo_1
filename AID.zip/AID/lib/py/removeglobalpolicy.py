from xml.dom.minidom import parse

# Check the parameters and print usage
if len(sys.argv) != 6:
   print("Usage:")
   print("wlst.sh globalpolicy.py <hostname> <portnumber> <username> <password> <AIAGlobalSecurityPolicyConfiguration.xml>")
   sys.exit("Must provide five arguments")

# Read from command line arguments
adminhost = sys.argv[1]
adminport = sys.argv[2]
usr = sys.argv[3]
password = sys.argv[4]
file = sys.argv[5]

# Connect to application server
adminurl='t3://'+adminhost+':'+adminport
try:
   connect(userConfigFile=usr,userKeyFile=password,url=adminurl)
except:
   raise Exception('Error connecting to server please check to see if the server exists')

   # Parse XML and delete policy sets
else:
   doc = parse(file)
   globalPolicySetNodes = doc.getElementsByTagName('GlobalPolicySet')
   for node1 in globalPolicySetNodes:
      policySetName = ''
      policyName = ''
      resourceType = ''
      pattern = ''
      for node2 in node1.childNodes:
         if node2.nodeName == 'policySetName':
            policySetName = node2.childNodes[0].data
         elif node2.nodeName == 'policyName':
            policyName = node2.childNodes[0].data
         elif node2.nodeName == 'resourceType':
            resourceType = node2.childNodes[0].data
         elif node2.nodeName == 'pattern':
            pattern =  node2.childNodes[0].data
      beginRepositorySession()
      deletePolicySet(policySetName)
      commitRepositorySession()
   print 'Detaching globally attached policy successful!'

disconnect()

