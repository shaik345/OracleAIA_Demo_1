import sys
from java.lang import System
import os
import wlstModule as wl

global props

host = sys.argv[1]
port=sys.argv[2]
usr = sys.argv[3]
password = sys.argv[4]
dsName=sys.argv[5]
jndiloc = sys.argv[6]
DBUsername=sys.argv[7]
DBPassword=sys.argv[8]
DBUrl=sys.argv[9]
targetServer=sys.argv[10]
serverType=sys.argv[11]+'s'
driverName=sys.argv[12]
InitialCapacity=sys.argv[13]
MaxCapacity=sys.argv[14]
CapacityIncrement=sys.argv[15]
ShrinkFrequencySeconds=sys.argv[16]
LoginDelaySeconds=sys.argv[17]
GlobalTransactionsProtocol=sys.argv[18]
isXA = sys.argv[19]
deployToAdminServer = sys.argv[20]
racCount=sys.argv[21]

url='t3://'+host+':'+port

prefix=dsName



try:
 connect(usr,password,url)
except:
 raise Exception('Error connecting to server please check to see if the server exists')

else:
    edit()
    cancelEdit('y')

    edit()
    startEdit()
    cd('/')

    servermb=getMBean(serverType+'/'+targetServer)
    if servermb is None:
     print '@@@ No server MBean found'
    else:

          # Create the Connection Pool.  The system resource will have
          # generated name of <dsName>+'-jdbc'
      try:
       print 'Here is the Resource Name: ' + dsName
 
       try:
         print 'attempting to create data source with name -'+ dsName
         for i in range(0, int(racCount)):
           #createDataSource(str(i))
           print i
         cd('/')
         jdbcSystemResource = create(dsName,'JDBCSystemResource')
       except:
              print 'WARNING!!! Data source already exists!!'
 
       else:
              #myFile = jdbcSystemResource.getDescriptorFileName()
          
              #print 'HERE IS THE JDBC FILE NAME: ' + myFile
          jdbcResource = jdbcSystemResource.getJDBCResource()
          jdbcResource.setName(dsName)
          dpBean = jdbcResource.getJDBCDataSourceParams()
          myName=jndiloc
          dpBean.setJNDINames([myName])
          
          cd('/')
          cd('/JDBCSystemResources/' + dsName + '/JDBCResource/' + dsName)
          dsList=''
          for i in range(0,int(racCount)-1):

            dsList += dsName+'-rac'+ str(i)+','

          dsList += dsName+ '-rac' + str(int(racCount)-1)
              #print dsList
          
          dpBean.setAlgorithmType('Load-Balancing')
              
          dpBean.setDataSourceList(dsList)
              
          jdbcSystemResource.addTarget(getMBean('/'+serverType+'/'+targetServer))
          if deployToAdminServer == 'true':
                jdbcSystemResource.addTarget(getMBean('/Servers/'+serverName))

      except:
        raise 
validate()
save()
activate()
dumpStack()
disconnect()

dumpStack()
disconnect()
