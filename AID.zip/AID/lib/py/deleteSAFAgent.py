import sys
from java.lang import System

import wlstModule as wl

global props

adminhost = sys.argv[1]
adminport = sys.argv[2]
adminuser = sys.argv[3]
adminpassword = sys.argv[4]
targetServer= sys.argv[5]
serverType=sys.argv[6]
safAgentName=sys.argv[7]

url='t3://'+adminhost+':'+adminport

try:
 connect(adminuser,adminpassword,url)
except:
 raise Exception('Error connecting to server please check to see if the server is reachable')

else:
    edit()
    cancelEdit('y')

    edit()
    startEdit()
    cd('/')

    servermb=getMBean( serverType+'s/'+targetServer)
    if servermb is None:
        print '@@@ No server MBean found for '+targetServer
    else:
         safAgentMbean = getMBean('SAFAgents'+'/'+safAgentName)
         if safAgentMbean is None:
           print 'SAF Agent "'+safAgentName+'" doesnt exist'
         else:
           destroy(safAgentName,'SAFAgents')
           print 'Deleted SAF Agent "'+safAgentName+'" successfully'


activate()

startEdit()

validate()
save()
activate(block="true")
dumpStack()
disconnect()
