import sys
from java.lang import System
import re
import wlstModule as wl

global props

host = sys.argv[1]
port=sys.argv[2]
usr = sys.argv[3]
password = sys.argv[4]
codeBaseURL=sys.argv[5]
permClass = sys.argv[6]
permTarget=sys.argv[7]
permActions=sys.argv[8]

appStripe = None
principalClass = None
principalName = None

adminurl='t3://'+host+':'+port

try:
 connect(userConfigFile=usr,userKeyFile=password,url=adminurl)
except:
 raise Exception('Error connecting to server please check to see if the server exists')

else:
  try:  
      import jpsWlstCmd
      jpsWlstCmd.grantPermission(appStripe=appStripe, codeBaseURL=codeBaseURL, principalClass=principalClass, principalName=principalName, permClass=permClass, permTarget=permTarget, permActions=permActions)
  except javax.management.MBeanException,err:
      found = re.search(r'Grant already exists for grantee',str(err))
      if found is not None :
          print 'WARNING!!! Grant already exists for grantee.'
      else:
          raise
dumpStack()
disconnect()
