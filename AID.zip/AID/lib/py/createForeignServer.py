import sys
from java.lang import System

import wlstModule as wl

print '@@@ Starting the script ...'
global props


adminhost = sys.argv[1]
adminport = sys.argv[2]
usr = sys.argv[3]
password = sys.argv[4]
targetServer= sys.argv[5]
serverType=sys.argv[6]
jmsForeignServerName = sys.argv[7]
dsJNDIProperty = sys.argv[8]
jmsModuleName = sys.argv[9]
jmsInitialContextFactory = sys.argv[10]

url='t3://'+adminhost+':'+adminport


try:
 connect(usr,password,url)
except:
 raise Exception('Error connecting to server please check to see if the server exists')

else:
    edit()
    cancelEdit('y')

    edit()
    startEdit()
    cd('/')

    servermb=getMBean( serverType+'s/'+targetServer)
    if servermb is None:
        print '@@@ No server MBean found'
    else:

        # Create JMS Foreign Server

      try:
          jmsModuleMBean = getMBean('JMSSystemResources'+'/'+jmsModuleName)
          jmsModule=jmsModuleMBean.getJMSResource()
          print 'Attempting to create Foreign Server :' + jmsForeignServerName
          jmsForeignServerObject = jmsModule.lookupForeignServer(jmsForeignServerName)
          if jmsForeignServerObject is None:
              jmsForeignMBean = jmsModule.createForeignServer(jmsForeignServerName)
              jmsModuleMBean.addTarget(servermb)
              jmsForeignMBean.setInitialContextFactory(jmsInitialContextFactory)
              jmsForeignMBean.setDefaultTargetingEnabled(true)
              jmsFSJNDINameMBean=jmsForeignMBean.createJNDIProperty('datasource')
              jmsFSJNDINameMBean.setValue(dsJNDIProperty)
              print 'Foreign Server created'
          else:
              print 'WARNING!!! Foreign Server already exists '
      except:
             raise
        
validate()
save()
activate(block="true")
dumpStack()
disconnect()
