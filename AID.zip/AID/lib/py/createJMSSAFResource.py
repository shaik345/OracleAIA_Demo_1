import sys
from java.lang import System

import wlstModule as wl

global props

adminhost = sys.argv[1]
adminport = sys.argv[2]
adminuser = sys.argv[3]
adminpassword = sys.argv[4]
targetServer= sys.argv[5]
serverType=sys.argv[6]
jmssafResourceType=sys.argv[7]
jmssafResourceName=sys.argv[8]
jmssafremotejndiName=sys.argv[9]
jmssaflocaljndiName=sys.argv[10]
jmsSAFNonPersistentQos=sys.argv[11]
jmsSAFImportedDestinations=sys.argv[12]
timeToLiveDefault=sys.argv[13]
useSAFTimeToLiveDefault=sys.argv[14]
unitOfOrderRouting=sys.argv[15]
jmsModuleName=sys.argv[16]

url='t3://'+adminhost+':'+adminport

try:
 connect(adminuser,adminpassword,url)
except:
 raise Exception('Error connecting to server please check to see if the server is reachable')

else:
    edit()
    cancelEdit('y')

    edit()
    startEdit()
    cd('/')

    servermb=getMBean( serverType+'s/'+targetServer)
    if servermb is None:
        print '@@@ No server MBean found for '+targetServer
    else:
      jmsModuleMbean = getMBean('JMSSystemResources'+'/'+jmsModuleName)
      jmsModule = jmsModuleMbean.getJMSResource()

      jmssafImportedDestinationsBean = jmsModule.lookupSAFImportedDestinations(jmsSAFImportedDestinations)
      if jmssafImportedDestinationsBean is None:
         print 'No SAF ImportedDestinations Found with name '+ jmsSAFImportedDestinations
      else:
         if jmssafResourceType == 'Queue': 
            jmssafResourceBean = jmssafImportedDestinationsBean.lookupSAFQueue(jmssafResourceName)
            if jmssafResourceBean is None:
               jmssafResourceBean = jmssafImportedDestinationsBean.createSAFQueue(jmssafResourceName)
               jmssafResourceBean.setRemoteJNDIName(jmssafremotejndiName)
               jmssafResourceBean.setNonPersistentQos(jmsSAFNonPersistentQos)
               jmssafResourceBean.setTimeToLiveDefault(int(timeToLiveDefault))
               if useSAFTimeToLiveDefault=='false' or useSAFTimeToLiveDefault=='False':
                  jmssafResourceBean.setUseSAFTimeToLiveDefault(False)
               elif useSAFTimeToLiveDefault=='true' or useSAFTimeToLiveDefault=='True':
                  jmssafResourceBean.setUseSAFTimeToLiveDefault(True)
               else:
                  print 'useSAFTimeToLiveDefault can only accept "false" or "true" as values. Found a different value useSAFTimeToLiveDefault : '+useSAFTimeToLiveDefault+' in DP, so setting it to default value "false"'
                  jmssafResourceBean.setUseSAFTimeToLiveDefault(False)
               jmssafResourceBean.setLocalJNDIName(jmssaflocaljndiName)
               jmssafResourceBean.setUnitOfOrderRouting(unitOfOrderRouting)
               print 'Created SAF ImportedDestinations Queue "'+jmssafResourceName+'" successfully'
            else:
               print 'WARNING!!! SAF ImportedDestinations Queue "'+jmssafResourceName+'" already exists'
         elif jmssafResourceType == 'Topic':
            print 'Creation of SAF Topic is not supported yet'

activate()

startEdit()

validate()
save()
activate(block="true")
dumpStack()
disconnect()
