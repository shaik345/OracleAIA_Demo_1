import sys
from java.lang import System

import wlstModule as wl

print '@@@ Starting the script ...'
global props


adminhost = sys.argv[1]
adminport = sys.argv[2]
usr = sys.argv[3]
password = sys.argv[4]
targetServer= sys.argv[5]
serverType=sys.argv[6]
jmsResourceType = sys.argv[7]
jmsResourceName = sys.argv[8]
jmsModuleName = sys.argv[9]
jmsForeignServerName = sys.argv[10]

url='t3://'+adminhost+':'+adminport


try:
 connect(usr,password,url)
except:
 raise Exception('Error connecting to server please check to see if the server exists')

else:
    edit()
    cancelEdit('y')

    edit()
    startEdit()
    cd('/')

    servermb=getMBean( serverType+'s/'+targetServer)
    if servermb is None:
        print '@@@ No server MBean found'
    else:
        jmsModuleMBean = getMBean('JMSSystemResources'+'/'+jmsModuleName)
        jmsModule=jmsModuleMBean.getJMSResource()

        jmsFSMBean = jmsModule.lookupForeignServer(jmsForeignServerName)
        if jmsFSMBean is None:
           print 'WARNING!!! JMS Foreign Server with name ' + jmsForeignServerName + ' does not exist'
           print 'So there are no Foreign Resources to be deleted'
        else:
           if jmsResourceType == 'ConnectionFactory':
              print 'Attempting to delete Foreign Connection Factory with name ' + jmsResourceName
              jmsFSCFMBean = jmsFSMBean.lookupForeignConnectionFactory(jmsResourceName)
              if jmsFSCFMBean is None:
                 print 'WARNING!!! Foreign ConnectionFactory does not exist'
              else:
                 jmsFSCF = jmsFSMBean.destroyForeignConnectionFactory(jmsFSCFMBean)
                 print 'Deleted Foreign ConnectionFactory'
           elif jmsResourceType == 'Queue':
              print 'Attempting to delete Foreign Destination Queue with name ' + jmsResourceName
              jmsFSQMBean = jmsFSMBean.lookupForeignDestination(jmsResourceName)
              if jmsFSQMBean is None:
                 print 'WARNING!!! Foreign Destination Queue does not exist'
              else:
                 jmsFSQ = jmsFSMBean.destroyForeignDestination(jmsFSQMBean)
                 print 'Deleted Queue'
           elif jmsResourceType == 'Topic':
              print 'Attempting to delete Foreign Destination Topic with name ' + jmsResourceName
              jmsFSQMBean = jmsFSMBean.lookupForeignDestination(jmsResourceName)
              if jmsFSQMBean is None:
                 print 'WARNING!!! Foreign Destination Topic does not exist'
              else:
                 jmsFSQ = jmsFSMBean.destroyForeignDestination(jmsFSQMBean)
                 print 'Deleted Topic'
           else:
              raise Exception('Invalid JmsResourceType passed as an argument')


validate()
save()
activate(block="true")
dumpStack()
disconnect()
