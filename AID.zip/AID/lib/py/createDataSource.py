import sys
from java.lang import System

import wlstModule as wl

global props

host = sys.argv[1]
port=sys.argv[2]
usr = sys.argv[3]
password = sys.argv[4]
poolname=sys.argv[5]
jndiloc = sys.argv[6]
DBUsername=sys.argv[7]
DBPassword=sys.argv[8]
DBUrl=sys.argv[9]
targetServer=sys.argv[10]
serverType=sys.argv[11]+'s'
driverName=sys.argv[12]
InitialCapacity=sys.argv[13]
MaxCapacity=sys.argv[14]
CapacityIncrement=sys.argv[15]
ShrinkFrequencySeconds=sys.argv[16]
LoginDelaySeconds=sys.argv[17]
GlobalTransactionsProtocol=sys.argv[18]
isXA = sys.argv[19]
deployToAdminServer = sys.argv[20]
SecondsToTrustAnIdlePoolConnection = sys.argv[21]
ConnectionCreationRetryFrequencySeconds = sys.argv[22]

url='t3://'+host+':'+port

prefix=poolname

try:
 connect(usr,password,url)
except:
 raise Exception('Error connecting to server please check to see if the server exists')

else:
    edit()
    cancelEdit('y')

    edit()
    startEdit()
    cd('/')

    servermb=getMBean(serverType+'/'+targetServer)
    if servermb is None:
     print '@@@ No server MBean found'
    else:

      	# Create the Connection Pool.  The system resource will have
    	  # generated name of <PoolName>+'-jdbc'
      try:
       print 'Here is the Resource Name: ' + poolname
 
       try:
         print 'attempting to create data source with name -'+ poolname
         jdbcSystemResource = create(poolname,'JDBCSystemResource')
       except:
              print 'WARNING!!! Data source already exists!!'
 
       else:
              myFile = jdbcSystemResource.getDescriptorFileName()
              print 'HERE IS THE JDBC FILE NAME: ' + myFile
 
              jdbcResource = jdbcSystemResource.getJDBCResource()
              jdbcResource.setName(poolname)
 
           	   # Create the DataSource Params
              dpBean = jdbcResource.getJDBCDataSourceParams()
              myName=jndiloc
              dpBean.setJNDINames([myName])
              
              if isXA == 'false':
                dpBean.setGlobalTransactionsProtocol(GlobalTransactionsProtocol)
 
              # Create the Driver Params
              drBean = jdbcResource.getJDBCDriverParams()
              drBean.setPassword(DBPassword)
              
              drBean.setUrl(DBUrl)
              drBean.setDriverName(driverName)
 
              propBean = drBean.getProperties()
              driverProps = Properties()
              driverProps.setProperty('user',DBUsername)
 
              e = driverProps.propertyNames()
              while e.hasMoreElements() :
                    propName = e.nextElement()
                    myBean = propBean.createProperty(propName)
                    myBean.setValue(driverProps.getProperty(propName))
 
           	   # Create the ConnectionPool Params
              ppBean = jdbcResource.getJDBCConnectionPoolParams()
              print int(InitialCapacity)
              ppBean.setInitialCapacity(int(InitialCapacity))
              ppBean.setMaxCapacity(int(MaxCapacity))
              ppBean.setCapacityIncrement(int(CapacityIncrement))
 
              ppBean.setShrinkFrequencySeconds(int(ShrinkFrequencySeconds))
 
              ppBean.setTestTableName('SQL SELECT 1 FROM DUAL\r\n\r\n')
 
              ppBean.setLoginDelaySeconds(int(LoginDelaySeconds))
              ppBean.setTestConnectionsOnReserve(true)
              ppBean.setSecondsToTrustAnIdlePoolConnection(int(SecondsToTrustAnIdlePoolConnection))
              ppBean.setConnectionCreationRetryFrequencySeconds(int(ConnectionCreationRetryFrequencySeconds))
 
           	   # Adding KeepXaConnTillTxComplete to help with in-doubt transactions.
              xaParams = jdbcResource.getJDBCXAParams()
              xaParams.setKeepXaConnTillTxComplete(1)
 
           	   # Add Target
              jdbcSystemResource.addTarget(getMBean('/'+serverType+'/'+targetServer))
              if deployToAdminServer == 'true':
                jdbcSystemResource.addTarget(getMBean('/Servers/'+serverName))
      except:
	    raise 
validate()
save()
activate()
dumpStack()
disconnect()
