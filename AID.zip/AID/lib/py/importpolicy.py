import sys
from java.lang import System
import wlstModule as wl
import pprint
from xml.dom.minidom import parse
global props

# Check the parameters and print usage
if len(sys.argv) < 6:
   pprint.pprint("Usage:")
   pprint.pprint("wlst.sh importpolicy.py <host name> <port number> <username> <password> <cloned policy1> <cloned policy2> ...")
   sys.exit("Must provide no less than five arguments")

# Read from command line arguments
adminhost = sys.argv[1]
adminport = sys.argv[2]
usr = sys.argv[3]
password = sys.argv[4]

# Connect to application server
adminurl='t3://'+adminhost+':'+adminport
try:
 connect(userConfigFile=usr,userKeyFile=password,url=adminurl)
except:
 raise Exception('Error connecting to server please check to see if the server exists')

# Import policies
for i in range(5, len(sys.argv)):
   importRepository(sys.argv[i])

disconnect()
pprint.pprint('Finish importing policies')
