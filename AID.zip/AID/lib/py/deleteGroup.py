import sys
from java.lang import System

global props

adminhost = sys.argv[1]
adminport = sys.argv[2]
usr = sys.argv[3]
password = sys.argv[4]
name = sys.argv[5]
namelist = []

while ',' in name:
 index = name.index(',')
 namelist.append(name[:index])
 name = name[index + 1:]
namelist.append(name)

url='t3://'+adminhost+':'+adminport

try:
 connect(usr,password,url)
except:
 raise Exception('Error connecting to server please check to see if the server exists')
else:
  try:
    i = 0
    while i < len(namelist):
     atnr=cmo.getSecurityConfiguration().getDefaultRealm().lookupAuthenticationProvider("DefaultAuthenticator")
     try:
       atnr.removeGroup(namelist[i])
       print namelist[i],' Group deleted.'
     except:
       print namelist[i],' Group not found.'
     i = i + 1

  except:
    dumpStack()
    raise 
dumpStack()
disconnect()
