import re
from xml.dom.minidom import parse

# Check the parameters and print usage
if len(sys.argv) != 9 and len(sys.argv) != 10:
   print("Usage:")
   print("wlst.sh removelocalpolicy.py <host name> <port number> <username> <password> <AIASecurityConfigurationProperties.xml> <server instance name/cluster name> <server type> <composite version> <partition name(optional)>")
   sys.exit("Must provide eight/nine(composite) arguments")

# Read from command line arguments
partitionName = 'default/'
adminhost = sys.argv[1]
adminport = sys.argv[2]
usr = sys.argv[3]
password = sys.argv[4]
file = sys.argv[5]
appServerName = sys.argv[6]
appServerType = sys.argv[7]
compositeVersion = '['+sys.argv[8]+']'
if len(sys.argv) == 10:
   partitionName = sys.argv[9]+'/'

# Detach policy from service
def detachSrvPolicy(applicationPath, node, moduleType, compositeVer):
   compName = ''
   portTypeName = ''
   policyName = ''
   for node3 in node2.childNodes:
      if node3.nodeName == 'Name':
         compName = node3.childNodes[0].data
      elif node3.nodeName == 'PortName':
         portTypeName = node3.childNodes[0].data
      elif node3.nodeName == 'WSPolicies':
         for node4 in node3.childNodes:
           if node4.nodeName == 'WSPolicyName':
              policyName = node4.childNodes[0].data
   detachWebServicePolicy(applicationPath, partitionName+compositeName+compositeVer, moduleType, compName, portTypeName, policyName)
   return

# Detach policy from reference
def detachRefPolicy(applicationPath, node, moduleType, compositeVer):
   compName = ''
   portTypeName = ''
   policyName = ''
   for node3 in node2.childNodes:
      if node3.nodeName == 'Name':
         compName = node3.childNodes[0].data
      elif node3.nodeName == 'PortName':
         portTypeName = node3.childNodes[0].data
      elif node3.nodeName == 'WSPolicies':
         for node4 in node3.childNodes:
            if node4.nodeName == 'WSPolicyName':
               policyName = node4.childNodes[0].data
   detachWebServiceClientPolicy(applicationPath, partitionName+compositeName+compositeVer, moduleType, compName, portTypeName, policyName)
   return

# Connect to application server
adminurl='t3://'+adminhost+':'+adminport
try:
   connect(userConfigFile=usr,userKeyFile=password,url=adminurl)
except:
   raise Exception('Error connecting to server please check to see if the server exists')

else:
   cd('/')
   mserver=appServerName
   if appServerType == 'Cluster':
      domainConfig()
      cd ('/Clusters/'+appServerName)
      managedServers=cmo.getServers()
      print managedServers
## Loop through managed servers
      domainRuntime()
      for managedServer in managedServers:
         try:
            managedServerName=managedServer.getName()
            print 'Trying ' + managedServerName
            cd('/ServerRuntimes/'+managedServerName)
            if cmo.getState() == 'RUNNING':
               mserver=managedServerName
               break;
         except:
            print 'Skipping ' + managedServerName

# Parse XML and create policy sets
   try:
      print 'Using server '+mserver
      appPath = '/'+domainName+'/'+mserver+'/soa-infra'
      policySetList = []
      doc = parse(file)
      configurationNodes = doc.getElementsByTagName('SecurityConfiguration')
      for node1 in configurationNodes:
         compositeName = re.sub('{.*}','',node1.attributes.get('compositeName').value)
         for node2 in node1.childNodes:
            if node2 != None and node2.attributes != None:
               if node2.attributes.get('resourceType').value == 'SOA-Service':
                  detachSrvPolicy(appPath, node2, 'soa', compositeVersion)
               elif node2.attributes.get('resourceType').value == 'SOA-Reference':
                  detachRefPolicy(appPath, node2, 'soa', compositeVersion)
   except:
      dumpStack()
      raise Exception( 'Detaching directly attached policy failed!')
   else:
      print 'Detaching directly attached policy successful!'

#         elif node2.attributes.get('resourceType').value == 'WebService':
#            detachSrvPolicy(node2, 'web', '')
#            stopApplication(applicationName)
#            startApplication(applicationName)
#         elif node2.attributes.get('resourceType').value == 'WebServiceClient':
#            detachRefPolicy(node2, 'web', '')
#            stopApplication(applicationName)
#            startApplication(applicationName)
