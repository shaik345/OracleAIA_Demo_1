import sys
from java.lang import System

import wlstModule as wl

print '@@@ Starting the script ...'
global props


adminhost = sys.argv[1]
adminport = sys.argv[2]
usr = sys.argv[3]
password = sys.argv[4]
targetServer= sys.argv[5]
serverType=sys.argv[6]
jmsResourceType = sys.argv[7]
jmsResourceName = sys.argv[8]
jmsResourceLocalJNDI = sys.argv[9]
jmsResourceRemoteJNDI = sys.argv[10]
jmsModuleName = sys.argv[11]
jmsForeignServerName = sys.argv[12]

url='t3://'+adminhost+':'+adminport


try:
 connect(usr,password,url)
except:
 raise Exception('Error connecting to server please check to see if the server exists')

else:
    edit()
    cancelEdit('y')

    edit()
    startEdit()
    cd('/')

    servermb=getMBean( serverType+'s/'+targetServer)
    if servermb is None:
        print '@@@ No server MBean found'
    else:
        jmsModuleMBean = getMBean('JMSSystemResources'+'/'+jmsModuleName)
        jmsModule=jmsModuleMBean.getJMSResource()

        jmsFSMBean = jmsModule.lookupForeignServer(jmsForeignServerName)
        if jmsFSMBean is None:
           print 'ERROR!!! JMS Foreign Server with name ' + jmsForeignServerName + ' does not exist'
        if jmsResourceType == 'ConnectionFactory':
               print 'Attempting to create Foreign Connection Factory with name ' + jmsResourceName
               jmsFSCFMBean = jmsFSMBean.lookupForeignConnectionFactory(jmsResourceName)
               if jmsFSCFMBean is None:
                  jmsFSCFMBean = jmsFSMBean.createForeignConnectionFactory(jmsResourceName)
                  jmsFSCFMBean.setLocalJNDIName(jmsResourceLocalJNDI)
                  jmsFSCFMBean.setRemoteJNDIName(jmsResourceRemoteJNDI)
                  print 'Created ConnectionFactory'
               else:
                  print 'WARNING!!! Foreign Connection Factory already exists'
        elif jmsResourceType == 'Queue':
               print 'Attempting to create Foreign Destination Queue with name ' + jmsResourceName
               jmsFSQMBean = jmsFSMBean.lookupForeignDestination(jmsResourceName)
               if jmsFSQMBean is None:
                  jmsFSQMBean = jmsFSMBean.createForeignDestination(jmsResourceName)
                  jmsFSQMBean.setLocalJNDIName(jmsResourceLocalJNDI)
                  jmsFSQMBean.setRemoteJNDIName(jmsResourceRemoteJNDI)
                  print 'Created Queue'
               else:
                  print 'WARNING!!! Foreign Destination Queue already exists'
        elif jmsResourceType == 'Topic':
               print 'Attempting to create Foreign Destination Topic with name ' + jmsResourceName
               jmsFSQMBean = jmsFSMBean.lookupForeignDestination(jmsResourceName)
               if jmsFSQMBean is None:
                  jmsFSQMBean = jmsFSMBean.createForeignDestination(jmsResourceName)
                  jmsFSQMBean.setLocalJNDIName(jmsResourceLocalJNDI)
                  jmsFSQMBean.setRemoteJNDIName(jmsResourceRemoteJNDI)
                  print 'Created Topic'
               else:
                  print 'WARNING!!! Foreign Destination Topic already exists'
        else:
            raise Exception('Invalid JmsResourceType passed as an argument')


validate()
save()
activate(block="true")
dumpStack()
disconnect()
