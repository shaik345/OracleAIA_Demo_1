import sys
from java.lang import System

import wlstModule as wl

print '@@@ Starting the script ...'
global props

adminhost = sys.argv[1]
adminport = sys.argv[2]
usr = sys.argv[3]
password = sys.argv[4]
targetServer= sys.argv[5]
serverType=sys.argv[6]+'s'
storeName = sys.argv[7]
storeType = sys.argv[8]
dbStoreDataSourceName = sys.argv[9]
dbStorePrefix = sys.argv[10]
url='t3://'+adminhost+':'+adminport

try:
 connect(usr,password,url)
except:
 raise Exception('Error connecting to server please check to see if the server exists')

else:
    edit()
    cancelEdit('y')


    edit()
    startEdit()
    cd('/')



    servermb=getMBean(serverType+'/'+targetServer)
    if servermb is None:
     print '@@@ No server MBean found'
    else:

     	# Create DataStore.  
		
      try:
       
		 if storeType == 'JDBCStore':
		   try:
				print 'attempting to create JDBC store with name :' + storeName
				dbStore = create(storeName,"JDBCStore")
		   except:
				print 'Error Creating JDBC Store..'
		   else:
				dbStore.addTarget(servermb)
				dbStoreDS = getMBean('SystemResources/'+dbStoreDataSourceName)
				print 'Datasource name : '+dbStoreDS.getJDBCResource().getName()
				dbStore.setDataSource(dbStoreDS)
				dbStore.setPrefixName(dbStorePrefix)
		 if storeType == 'FileStore':
		   try:
				print 'attempting to create a File store with name: '+ storeName
				fileStore = create(storeName,"FileStore")
		   except:
				print 'Error Creating File Store....'+ storeName		 
		   else:
				fileStore.addTarget(servermb)
				fileStore.setDirectory(storeName)
      except:
	    raise 
validate()
save()
activate()
dumpStack()
disconnect()
