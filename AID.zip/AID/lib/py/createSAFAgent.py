import sys
from java.lang import System

import wlstModule as wl

global props

adminhost = sys.argv[1]
adminport = sys.argv[2]
adminuser = sys.argv[3]
adminpassword = sys.argv[4]
targetServer= sys.argv[5]
serverType=sys.argv[6]
safAgentName=sys.argv[7]
persistentStore=sys.argv[8]
serviceType=sys.argv[9]

url='t3://'+adminhost+':'+adminport

try:
 connect(adminuser,adminpassword,url)
except:
 raise Exception('Error connecting to server please check to see if the server is reachable')

else:
    edit()
    cancelEdit('y')

    edit()
    startEdit()
    cd('/')

    servermb=getMBean( serverType+'s/'+targetServer)
    if servermb is None:
        print '@@@ No server MBean found for '+targetServer
    else:
         safAgentMbean = getMBean('SAFAgents'+'/'+safAgentName)
         if safAgentMbean is None:
            safAgentMbean = create(safAgentName,'SAFAgents')
            persistentStoreMbean = getMBean('FileStores/'+persistentStore)
            if persistentStoreMbean is None:
               print 'Persistent Store "'+persistentStore+'" not found'
            else:
               safAgentMbean.setStore(persistentStoreMbean)
            safAgentMbean.addTarget(servermb)
            safAgentMbean.setServiceType(serviceType)
            print 'Created SAF Agent "'+safAgentName+'" successfully'
         else:
              print 'WARNING!!! SAF Agent "'+safAgentName+'" already exists!!'


activate()

startEdit()

validate()
save()
activate(block="true")
dumpStack()
disconnect()
