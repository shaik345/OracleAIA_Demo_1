import sys
from java.lang import System

global props

adminhost = sys.argv[1]
adminport = sys.argv[2]
usr = sys.argv[3]
password = sys.argv[4]
targetserver = sys.argv[5]
managedserver = sys.argv[6]
managedserverport = sys.argv[7]

adminurl='t3://'+adminhost+':'+adminport
soaurl='t3://'+managedserver+':'+managedserverport

try:
      connect(userConfigFile=usr,userKeyFile=password,url=adminurl)
except:
 raise Exception('Error connecting to server please check to see if the server exists')

else:
    try:


	dir=cmo.getRootDirectory()
        errorlog=dir+"/servers/"+targetserver+"/logs/mapper-error.log"
        setLogLevel(target=targetserver, logger="oracle.apps.mapper",addLogger=1,level="NOTIFICATION:1")
        first = listLogHandlers(target=targetserver, name='mapper-log-error-handler')
        if not first:
                configureLogHandler(target=targetserver, name="mapper-log-error-handler",handlerType="oracle.core.ojdl.logging.ODLHandlerFactory",level="TRACE:32",maxFileSize="10485760",maxLogSize="104857600",addToLogger="oracle.apps.mapper",addHandler=true,path=errorlog,useParentHandlers=false,format="UTF-8")

    except:
     dumpStack()
     raise
dumpStack()
disconnect()


exit()

