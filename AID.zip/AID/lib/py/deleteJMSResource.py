import sys
from java.lang import System

import wlstModule as wl

print '@@@ Starting the script ...'
global props


adminhost = sys.argv[1]
adminport = sys.argv[2]
usr = sys.argv[3]
password = sys.argv[4]
targetServer= sys.argv[5]
serverType=sys.argv[6]
jmsResourceType = sys.argv[7]
jmsResourceName = sys.argv[8]
jmsResourceJNDI = sys.argv[9]
jmsModuleName = sys.argv[10]
jmsSubDeploymentName = sys.argv[11]

url='t3://'+adminhost+':'+adminport


try:
 connect(usr,password,url)
except:
 raise Exception('Error connecting to server please check to see if the server exists')

else:
    edit()
    cancelEdit('y')

    edit()
    startEdit()
    cd('/')

    servermb=getMBean( serverType+'s/'+targetServer)
    if servermb is None:
        print '@@@ No server MBean found'
    else:
        jmsModuleMbean = getMBean('JMSSystemResources'+'/'+jmsModuleName)
        jmsModule = jmsModuleMbean.getJMSResource()

        if jmsResourceType == 'ConnectionFactory':
            print 'Attempting to delete ConnectionFactory with name ' + jmsResourceName
            jmsResourceBean = jmsModule.lookupConnectionFactory(jmsResourceName)
            if jmsResourceBean is None:
                print 'WARNING!!! Connection Factory does not exist!!'
            else:
                jmsConnectionFactory = jmsModule.destroyConnectionFactory(jmsResourceBean)
                print 'Deleted the ConnectionFactory ' + jmsResourceName
            
        elif jmsResourceType == 'Queue':
            if serverType == 'Cluster':
                 print 'Attempting to delete Queue with name ' + jmsResourceName
                 jmsResourceBean = jmsModule.lookupUniformDistributedQueue(jmsResourceName)
                 if jmsResourceBean is None:
                    print 'WARNING!!! Queue does not exist'
                 else:
                    jmsQueue = jmsModule.destroyUniformDistributedQueue(jmsResourceBean)
                    print '***************** Queue deleted in cluster ***************'
                 print 'Attempting to delete ErrorQueue with name ' + jmsResourceName + '_ErrorQ'
                 jmsErrorResourceBean = jmsModule.lookupUniformDistributedQueue(jmsResourceName+'_ErrorQ')
                 if jmsErrorResourceBean is None:
                    print 'WARNING!!! ErrorQueue does not exist'
                 else:
                    jmsErrorQueue = jmsModule.destroyUniformDistributedQueue(jmsErrorResourceBean)
                    print '***************** Error Queue deleted in cluster ***************'
            else:
                 print 'Attempting to delete Queue with name ' + jmsResourceName
                 jmsResourceBean = jmsModule.lookupQueue(jmsResourceName)
                 if jmsResourceBean is None:
                    print 'WARNING!!! Queue does not exist'
                 else:
                    jmsQueue = jmsModule.destroyQueue(jmsResourceBean)
                    print '***************** Queue deleted in Server ***************'
                 print 'Attempting to delete ErrorQueue with name ' + jmsResourceName + '_ErrorQ'
                 jmsErrorResourceBean = jmsModule.lookupQueue(jmsResourceName+'_ErrorQ')
                 if jmsErrorResourceBean is None:
                    print 'WARNING!!! ErrorQueue does not exist'
                 else:
                    jmsErrorQueue = jmsModule.destroyQueue(jmsErrorResourceBean)
                    print '***************** Error Queue deleted in Server ***************'   
	    print 'Deleted Queue'
        elif jmsResourceType == 'Topic':
            if serverType == 'Cluster':
                 print 'Attempting to delete Topic with name ' + jmsResourceName
                 jmsResourceBean = jmsModule.lookupUniformDistributedTopic(jmsResourceName)
                 if jmsResourceBean is None:
                    print 'WARNING!!! Topic does not exist'
                 else:
                    jmsTopic = jmsModule.destroyUniformDistributedTopic(jmsResourceBean)
                    print '***************** Topic deleted in cluster ***************'
                 print 'Attempting to delete ErrorQueue with name ' + jmsResourceName + '_ErrorQ'
                 jmsErrorResourceBean = jmsModule.lookupUniformDistributedQueue(jmsResourceName+'_ErrorQ')
                 if jmsErrorResourceBean is None:
                    print 'WARNING!!! ErrorQueue does not exist'
                 else:
                    jmsErrorQueue = jmsModule.destroyUniformDistributedQueue(jmsErrorResourceBean)
                    print '***************** Error Queue deleted in cluster ***************'
            else:
                 print 'Attempting to delete Topic with name ' + jmsResourceName
                 jmsResourceBean = jmsModule.lookupTopic(jmsResourceName)
                 if jmsResourceBean is None:
                    print 'WARNING!!! Topic does not exist'
                 else:
                    jmsTopic = jmsModule.destroyTopic(jmsResourceBean)
                    print '***************** Topic deleted in Server ***************'
                 print 'Attempting to delete ErrorQueue with name ' + jmsResourceName + '_ErrorQ'
                 jmsErrorResourceBean = jmsModule.lookupQueue(jmsResourceName+'_ErrorQ')
                 if jmsErrorResourceBean is None:
                    print 'WARNING!!! ErrorQueue does not exist'
                 else:
                    jmsErrorQueue = jmsModule.destroyQueue(jmsErrorResourceBean)
                    print '***************** Error Queue deleted in Server ***************'            
	    print 'Deleted Topic'
        
	else:
            raise Exception('Invalid JmsResourceType passed as an argument')


validate()
save()
activate(block="true")
dumpStack()
disconnect()
