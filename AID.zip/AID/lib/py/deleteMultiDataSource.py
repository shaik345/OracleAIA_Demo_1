import sys
from java.lang import System
import os
import wlstModule as wl

global props

host = sys.argv[1]
port=sys.argv[2]
usr = sys.argv[3]
password = sys.argv[4]
dsName=sys.argv[5]

url='t3://'+host+':'+port

prefix=dsName



try:
 connect(usr,password,url)
except:
 raise Exception('Error connecting to server please check to see if the server exists')

else:
    edit()
    cancelEdit('y')

    edit()
    startEdit()
    cd('/')
    try:
         cmo.destroyJDBCSystemResource(getMBean('/SystemResources/'+dsName))
    except:
         print 'WARNING!!! Data source deletion error the Multi Data source might not exist !!'	 
    else:
         print 'Data source deleted !!'
	 
validate()
save()
activate()
dumpStack()
disconnect()

dumpStack()
disconnect()
