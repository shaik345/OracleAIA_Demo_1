
connect(sys.argv[1],sys.argv[2],sys.argv[3])


setLogLevel(logger="oracle.aia.logging.error",addLogger=1,level="NOTIFICATION:1")
setLogLevel(logger="oracle.aia.logging.trace",addLogger=1,level="NOTIFICATION:1")
setLogLevel(logger="oracle.aia.logging.debug",addLogger=1,level="NOTIFICATION:1")
first = listLogHandlers(name='aia-logging-error-handler')
if not first:
	configureLogHandler(name="aia-logging-error-handler",handlerType="oracle.core.ojdl.logging.ODLHandlerFactory",level="TRACE:32",maxFileSize="10485760",maxLogSize="104857600",addToLogger="oracle.aia.logging.error",addHandler=true,path="${domain.home}/servers/${weblogic.Name}/logs/error",useParentHandlers=false,format="ODL-XML")
second = listLogHandlers(name='aia-logging-trace-handler')	
if not second:
	configureLogHandler(name="aia-logging-trace-handler",handlerType="oracle.core.ojdl.logging.ODLHandlerFactory",level="TRACE:32",maxFileSize="10485760",maxLogSize="104857600",addToLogger="oracle.aia.logging.error",addHandler=true,path="${domain.home}/servers/${weblogic.Name}/logs/trace",useParentHandlers=false,format="ODL-XML")
third = listLogHandlers(name='aia-logging-debug-handler')
if not third:
	configureLogHandler(name="aia-logging-debug-handler",handlerType="oracle.core.ojdl.logging.ODLHandlerFactory",level="TRACE:32",maxFileSize="10485760",maxLogSize="104857600",addToLogger="oracle.aia.logging.debug",addHandler=true,path="${domain.home}/servers/${weblogic.Name}/logs/aia-debug.log",useParentHandlers=false,encoding="UTF-8")

exit()
