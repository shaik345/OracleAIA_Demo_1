import sys
from java.lang import System

import wlstModule as wl

print '@@@ Starting the script ...'
global props


adminhost = sys.argv[1]
adminport = sys.argv[2]
usr = sys.argv[3]
password = sys.argv[4]
targetServer= sys.argv[5]
serverType=sys.argv[6]
jmsResourceName = sys.argv[7]
jmsResourceJNDI = sys.argv[8]
jmsModuleName = sys.argv[9]
jmsSubDeploymentName = sys.argv[10]

url='t3://'+adminhost+':'+adminport


try:
 connect(usr,password,url)
except:
 raise Exception('Error connecting to server please check to see if the server exists')

else:
    edit()
    cancelEdit('y')

    edit()
    startEdit()
    cd('/')

    servermb=getMBean( serverType+'s/'+targetServer)
    if servermb is None:
        print '@@@ No server MBean found'
    else:
        jmsModuleMbean = getMBean('JMSSystemResources'+'/'+jmsModuleName)
        jmsModule = jmsModuleMbean.getJMSResource()
        print 'Attempting to delete ConnectionFactory with name ' + jmsResourceName
        jmsResourceBean = jmsModule.lookupConnectionFactory(jmsResourceName)
        if jmsResourceBean is None:
            print 'WARNING!!! Connection Factory does not exist!!'
        else:
            jmsConnectionFactory = jmsModule.destroyConnectionFactory(jmsResourceBean)
            print 'Deleted the ConnectionFactory ' + jmsResourceName

validate()
save()
activate(block="true")
dumpStack()
disconnect()
