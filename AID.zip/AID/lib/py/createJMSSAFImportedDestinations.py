import sys
from java.lang import System

import wlstModule as wl

global props

adminhost = sys.argv[1]
adminport = sys.argv[2]
adminuser = sys.argv[3]
adminpassword = sys.argv[4]
targetServer= sys.argv[5]
serverType=sys.argv[6]
jmssafImportedDestinationsName=sys.argv[7]
jmsSAFRemoteContext=sys.argv[8]
jmsSAFErrorHandling=sys.argv[9]
jndiPrefix=sys.argv[10]
timeToLiveDefault=sys.argv[11]
useSAFTimeToLiveDefault=sys.argv[12]
defaultTargetingEnabled=sys.argv[13]
jmsModuleName=sys.argv[14]

url='t3://'+adminhost+':'+adminport

try:
 connect(adminuser,adminpassword,url)
except:
 raise Exception('Error connecting to server please check to see if the server is reachable')

else:
    edit()
    cancelEdit('y')

    edit()
    startEdit()
    cd('/')

    servermb=getMBean( serverType+'s/'+targetServer)
    if servermb is None:
        print '@@@ No server MBean found for '+targetServer
    else:
      jmsModuleMbean = getMBean('JMSSystemResources'+'/'+jmsModuleName)
      jmsModule = jmsModuleMbean.getJMSResource()
      jmssafImportedDestinationsBean = jmsModule.lookupSAFImportedDestinations(jmssafImportedDestinationsName)
      if jmssafImportedDestinationsBean is None:
         jmssafImportedDestinationsBean = jmsModule.createSAFImportedDestinations(jmssafImportedDestinationsName)
         jmssafImportedDestinationsBean.setJNDIPrefix(jndiPrefix)
         jmssafRemoteContextBean = jmsModule.lookupSAFRemoteContext(jmsSAFRemoteContext)
         if jmssafRemoteContextBean is None:
            print 'No SAF RemoteContext "'+jmsSAFRemoteContext+'" Found'
         else:
            jmssafImportedDestinationsBean.setSAFRemoteContext(jmssafRemoteContextBean)
         jmssafErrorHandlingBean = jmsModule.lookupSAFErrorHandling(jmsSAFErrorHandling)
         if jmssafErrorHandlingBean is None:
            print 'No SAF ErrorHandling "'+jmsSAFErrorHandling+'" Found'
         else:
            jmssafImportedDestinationsBean.setSAFErrorHandling(jmssafErrorHandlingBean)
         jmssafImportedDestinationsBean.setTimeToLiveDefault(int(timeToLiveDefault))
         if useSAFTimeToLiveDefault=='false' or useSAFTimeToLiveDefault=='False':
            jmssafImportedDestinationsBean.setUseSAFTimeToLiveDefault(False)
         elif useSAFTimeToLiveDefault=='true' or useSAFTimeToLiveDefault=='True':
            jmssafImportedDestinationsBean.setUseSAFTimeToLiveDefault(True)
         else:
            print 'useSAFTimeToLiveDefault can only accept "false" or "true" as values. Found a different value useSAFTimeToLiveDefault : '+useSAFTimeToLiveDefault+' in DP, so setting it to default value "false"'
            jmssafImportedDestinationsBean.setUseSAFTimeToLiveDefault(False)
         if defaultTargetingEnabled=='false' or defaultTargetingEnabled=='False':
            jmssafImportedDestinationsBean.setDefaultTargetingEnabled(False)
         elif defaultTargetingEnabled=='true' or defaultTargetingEnabled=='True':
            jmssafImportedDestinationsBean.setDefaultTargetingEnabled(True)
         else:
            print 'defaultTargetingEnabled can only accept "false" or "true" as values. Found a different value defaultTargetingEnabled : '+defaultTargetingEnabled+' in DP, so setting it to default value "true"'
            jmssafImportedDestinationsBean.setDefaultTargetingEnabled(True)
         print 'Created SAF ImportedDestinations "'+jmssafImportedDestinationsName+'" successfully'
      else:
         print 'WARNING!!! SAF ImportedDestinations "'+jmssafImportedDestinationsName+'" already exists' 

activate()

startEdit()

validate()
save()
activate(block="true")
dumpStack()
disconnect()
