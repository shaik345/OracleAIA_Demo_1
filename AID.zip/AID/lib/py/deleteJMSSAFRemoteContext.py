import sys
from java.lang import System

import wlstModule as wl

global props

adminhost = sys.argv[1]
adminport = sys.argv[2]
adminuser = sys.argv[3]
adminpassword = sys.argv[4]
targetServer= sys.argv[5]
serverType=sys.argv[6]
jmssafRemoteContextName=sys.argv[7]
jmsModuleName=sys.argv[8]

url='t3://'+adminhost+':'+adminport

try:
 connect(adminuser,adminpassword,url)
except:
 raise Exception('Error connecting to server please check to see if the server is reachable')

else:
    edit()
    cancelEdit('y')

    edit()
    startEdit()
    cd('/')

    servermb=getMBean( serverType+'s/'+targetServer)
    if servermb is None:
        print '@@@ No server MBean found for '+targetServer
    else:
      jmsModuleMbean = getMBean('JMSSystemResources'+'/'+jmsModuleName)
      jmsModule = jmsModuleMbean.getJMSResource()
      jmssafRemoteContextBean = jmsModule.lookupSAFRemoteContext(jmssafRemoteContextName)
      if jmssafRemoteContextBean is None:
         print 'WARNING!!! SAF RemoteContext "'+jmssafRemoteContextName+'" does not exist'
      else:
         jmsModule.destroySAFRemoteContext(jmssafRemoteContextBean)
         print 'Deleted SAF RemoteContext "'+jmssafRemoteContextName+'" Successfully'		 

activate()

startEdit()
validate()
save()
activate(block="true")
dumpStack()
disconnect()
