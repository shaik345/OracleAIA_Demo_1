import sys
from java.lang import System

import wlstModule as wl

print '@@@ Starting the script ...'
global props



hostname = sys.argv[1]
wlport=sys.argv[2]
adminuser = sys.argv[3]
adminpassword = sys.argv[4]
soaserverhostname = sys.argv[5]
soaserverport=sys.argv[6]
serverType = sys.argv[7]
soaservername = sys.argv[8]
action = sys.argv[9]

adminURL ='t3://'+hostname+':'+wlport
soaURL  = 't3://'+soaserverhostname+':'+soaserverport
connect(adminuser,adminpassword,adminURL)
if action == 'start' :
  start(soaservername,serverType, soaURL, block='true')
if action == 'shutdown' :
  shutdown(soaservername,serverType, soaURL,force='true', block='true')
