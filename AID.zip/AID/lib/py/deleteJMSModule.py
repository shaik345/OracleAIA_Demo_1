import sys
from java.lang import System

import wlstModule as wl

print '@@@ Starting the script ...'
global props


adminhost = sys.argv[1]
adminport = sys.argv[2]
usr = sys.argv[3]
password = sys.argv[4]
jmsModuleName = sys.argv[5]

url='t3://'+adminhost+':'+adminport


try:
 connect(usr,password,url)
except:
 raise Exception('Error connecting to server please check to see if the server exists')

else:
    edit()
    cancelEdit('y')

    edit()
    startEdit()
    cd('/')
    try:
        print 'attempting to delete JMS Module :' + jmsModuleName
        cmo.destroyJMSSystemResource(getMBean('JMSSystemResources'+'/'+jmsModuleName))
    except:
        print 'Error deleting JMS Module..'
    else:
        print 'JMSModule deleted successfully...'

validate()
save()
activate(block="true")
dumpStack()
disconnect()
