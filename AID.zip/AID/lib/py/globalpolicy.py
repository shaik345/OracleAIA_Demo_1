from xml.dom.minidom import parse

# Check the parameters and print usage
if len(sys.argv) != 9:
   print("Usage:")
   print("wlst.sh globalpolicy.py <host name> <port number> <username> <password> <AIAGlobalSecurityPolicyConfiguration.xml> <domain name> <server instance name/cluster name> <server type>")
   sys.exit("Must provide eight arguments")

# Read from command line arguments
adminhost = sys.argv[1]
adminport = sys.argv[2]
usr = sys.argv[3]
password = sys.argv[4]
file = sys.argv[5]
curDomainName = sys.argv[6]
srvInstanceName = sys.argv[7]
srvType = sys.argv[8]

# Connect to application server
adminurl='t3://'+adminhost+':'+adminport
try:
   connect(userConfigFile=usr,userKeyFile=password,url=adminurl)
except:
   raise Exception('Error connecting to server please check to see if the server exists')

else:
   # Parse XML and create policy sets
   policySetList = []
   doc = parse(file)
   globalPolicySetNodes = doc.getElementsByTagName('GlobalPolicySet')
   for node1 in globalPolicySetNodes:
      policySetName = ''
      policyName = ''
      resourceType = ''
      pattern = ''
      appPath = 'Domain(\''+curDomainName+'\') and '
      for node2 in node1.childNodes:
         if node2.nodeName == 'policySetName':
            policySetName = node2.childNodes[0].data
         elif node2.nodeName == 'policyName':
            policyName = node2.childNodes[0].data
         elif node2.nodeName == 'resourceType':
            resourceType = node2.childNodes[0].data
         elif node2.nodeName == 'pattern':
            pattern =  node2.childNodes[0].data
      policySetList.append(policySetName)
      beginRepositorySession()
      deletePolicySet(policySetName)
      commitRepositorySession()
      beginRepositorySession()
      if srvType != 'Cluster':
         appPath = appPath+'Server(\''+srvInstanceName+'\') and '
      createPolicySet(policySetName,resourceType, appPath+pattern)
      attachPolicySetPolicy(policyName)
      commitRepositorySession()

   # Validate committed PolicySets
   for items in policySetList:
      validatePolicySet(items)
   print 'Attaching globally attached policy successful!'
disconnect()
