# Modified Script to manage adding a Node in Cluster
# Modified By : NLPADMAN
import sys
from java.lang import System
import getopt
import string

modulePath = os.environ["AIA_HOME"] + '/Infrastructure/Install/AID/lib/py'
if modulePath not in sys.path:
	sys.path.append(modulePath)
import findStoreTargetServer

import wlstModule as wl
global props


adminhost = sys.argv[1]
adminport = sys.argv[2]
usr = sys.argv[3]
password = sys.argv[4]
clusterName = sys.argv[5]
jmsServer = sys.argv[6]
storeName = sys.argv[7]
storeType = sys.argv[8]
jmsModuleName = sys.argv[9]
jmsSubDeploymentName = sys.argv[10]
dbStoreDS = sys.argv[11]


def createJMSModule():
    jmsModuleMBean = create(jmsModuleName,'JMSSystemResource')
    print '************  '+jmsModuleName+' created ***************'
    return jmsModuleMBean

def createSubDeployment():
    cd('/')
    cd('JMSSystemResources/'+jmsModuleName)
    subDepMbean = create(jmsSubDeploymentName, 'SubDeployment')
    print '************  '+ jmsSubDeploymentName+' created *********************'
    return subDepMbean

def createJMSDataStore(servermb, token, storeType):
    if storeType == 'JDBCStore':
       print 'attempting to create JDBC store with name :' + storeName + "_"+token
       dataStore = create(storeName + "_"+token,"JDBCStore")
       dataStore.addTarget(servermb)
       dataStoreDS = getMBean('SystemResources/'+ dbStoreDS)
       print 'Datasource name : '+dataStoreDS.getJDBCResource().getName()
       dataStore.setDataSource(dataStoreDS)
       dataStore.setPrefixName(storeName + "_"+token)
       print '*******  '+ storeName +'_'+token +' created  ******'

    if storeType == 'FileStore':
       dataStore = create( storeName+"_"+token, storeType)
       dataStore.addTarget(servermb)
       dataStore.setDirectory(storeName+ "_"+token)
       print '*******  '+storeName+'_'+token +' created  ******'
    return dataStore

def createJMSServer(servermb, token, fileStore):
    jmsServerName= jmsServer + '_' + token
    jmsServerMbean  = create(jmsServerName, 'JMSServer')
    jmsServerMbean.addTarget(servermb)
    jmsServerMbean.setPersistentStore(fileStore)
    print '********** '+ jmsServerName +' created  ***********'
    return jmsServerMbean
				

url='t3://'+adminhost+':'+adminport

try:
	connect(usr,password,url)
except:
	raise Exception('Error connecting to server please check to see if the server exists')
else:
    edit()
    cancelEdit('y')

    edit()
    startEdit()
    cd('/')
    try:		
		# check jms module exists, if not create new
		jmsModuleMBean = getMBean('JMSSystemResources/'+jmsModuleName)				
		if jmsModuleMBean is None:			
			print 'attempting to create JMS Module :' + jmsModuleName
			jmsModuleMBean = createJMSModule()			
			cd('/')
			print clusterName	  
			clustermb = getMBean('Clusters/'+clusterName)
			# associate your module to cluster
			jmsModuleMBean.addTarget(clustermb)
		else:
			print 'WARNING!!! JMS Module already exists!!'						
			
		# check jms sub deployment exists, if not create new	
		cd('/')	
		subDepMbean = getMBean('JMSSystemResources/'+jmsModuleName+'/SubDeployments/'+jmsSubDeploymentName)
		if subDepMbean is None:
			print 'attempting to create Sub Deployment :'+jmsSubDeploymentName
			subDepMbean = createSubDeployment()
		else:
			print 'WARNING!!! Sub Deployment already exists!!'
		
		dSTargetServers = findStoreTargetServer.lsDataStoreTargetServers(storeType, storeName)										
				
		cd('/')
		s = ls('/Clusters/' + clusterName + '/Servers')		
		for token in s.split("drw-"):
			token=token.strip().lstrip().rstrip()
			if not token == 'AdminServer' and not token == '':
				cd('/')
				if token not in dSTargetServers:
					servermb=getMBean('Servers'+'/'+token)	
					try:
						print 'attempting to create Data Store :'+storeName+"_"+str(dSTargetServers[0])					
						dataStore = createJMSDataStore(servermb, str(dSTargetServers[0]), storeType)					
						print 'attempting to create JMS Server :'+jmsServer+"_"+str(dSTargetServers[0])
						jmsServerMbean = createJMSServer(servermb, str(dSTargetServers[0]), dataStore)
						subDepMbean.addTarget(jmsServerMbean)
					except:
						print 'Error creating Data Store :'+storeName+"_"+str(dSTargetServers[0])	
					dSTargetServers[0]=dSTargetServers[0]+1
				else:
					print 'WARNING!!! Data Store already exists!!'
    except:
		raise
     
validate()
save()
activate(block="true")
dumpStack()
disconnect()


