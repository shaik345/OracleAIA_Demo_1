import sys
from java.lang import System
import getopt
import string

modulePath = os.environ["AIA_HOME"] + '/Infrastructure/Install/AID/lib/py'
if modulePath not in sys.path:
	print modulePath + ' imported!!!'
	sys.path.append(modulePath)
import findStoreTargetServer

import wlstModule as wl
global props

adminhost = sys.argv[1]
adminport = sys.argv[2]
usr = sys.argv[3]
password = sys.argv[4]
clusterName= sys.argv[5]
serverType=sys.argv[6]+'s'
jmsServer = sys.argv[7]
storeType = sys.argv[8]
storeName = sys.argv[9]
jmsModuleName = sys.argv[10]
jmsSubDeploymentName = sys.argv[11]


def deleteJMSModule():
    delete(jmsModuleName,'JMSSystemResource')
    print '************  '+jmsModuleName+' Deleted ***************'

def deleteJMSDataStore(dataStoreName):
    delete(dataStoreName, storeType)
    print '*******  '+dataStoreName +' Deleted  ******'

def deleteJMSServer(jmsServerName):    
    delete(jmsServerName, 'JMSServer')
    print '********** '+ jmsServerName +' Deleted  ***********'

url='t3://'+adminhost+':'+adminport

try:
 connect(usr,password,url)
except:
 raise Exception('Error connecting to server please check to see if the server exists')

else:
    edit()
    cancelEdit('y')

    edit()
    startEdit()
    cd('/')
    try:      
      deleteJMSModule()
      cd('/')
      clustermb = getMBean('Clusters/'+clusterName)
      s = ls('/Clusters/' + clusterName + '/Servers')
      for token in s.split("drw-"):
			token=token.strip().lstrip().rstrip()
			if len(token) > 0 and not token == 'AdminServer':
				print token + ' Target server ' + jmsServer + ' jms server name'				
				jmsServerList = findStoreTargetServer.lsTargetServerJMSServers(token, jmsServer)								
				for jmsServerSelected in jmsServerList:				
					dataStoreList = findStoreTargetServer.lsJMSServerDataStores(jmsServerSelected)		
					cd('/')
					deleteJMSServer(jmsServerSelected)					
					for dataStore in dataStoreList:
						deleteJMSDataStore(dataStore)				
					
    except:
     	raise

validate()
save()
activate(block="true")
dumpStack()
disconnect()



